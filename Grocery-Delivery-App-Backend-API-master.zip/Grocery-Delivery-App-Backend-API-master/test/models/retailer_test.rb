require 'test_helper'

class RetailerTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
