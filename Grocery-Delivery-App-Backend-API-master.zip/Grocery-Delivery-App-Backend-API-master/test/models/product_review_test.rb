require 'test_helper'

class ProductReviewTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
