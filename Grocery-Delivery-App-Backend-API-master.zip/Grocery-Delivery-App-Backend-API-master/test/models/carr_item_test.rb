require 'test_helper'

class CarrItemTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
