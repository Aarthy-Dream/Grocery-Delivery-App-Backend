class Driver < ApplicationRecord
    has_many :orders
end
