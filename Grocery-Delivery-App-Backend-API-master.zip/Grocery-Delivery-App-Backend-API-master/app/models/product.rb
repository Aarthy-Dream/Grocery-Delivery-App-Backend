class Product < ApplicationRecord

end
